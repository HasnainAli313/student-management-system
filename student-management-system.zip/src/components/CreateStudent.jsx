import { addDoc, collection } from 'firebase/firestore'
import React from 'react'
import { useState } from 'react'
import {db} from '../firebaseConfig'
function CreateStudent() {

    const [name, setName] = useState("")
    const [age, setAge] = useState("")
    const [isCreatingUser ,setIsCreatingUser] = useState(false)

    const handleSubmit = async(e)=> {
        e.preventDefault()
        setIsCreatingUser(true)
        try{
          await addDoc(collection(db,'students'),{
            name:name,
             age:Number(age)
          })
        setIsCreatingUser(false)
          setName("")
          setAge("")
          
        }catch(error){
            console.log("Error creating user: " + error)
        setIsCreatingUser(false)
        }
    }

  return (
    <div>
      <form className='form' onSubmit={handleSubmit}>
        <input type="text" value={name}  onChange={(e) => setName(e.target.value)} placeholder='Enter student name' required/>
        <input type="number"  value={age} onChange={(e) => setAge(e.target.value)} placeholder='Enter student age' required/>
        <button type='submit' onClick={handleSubmit}>{isCreatingUser ? 'Creating...' : "Create User"} </button>
      </form>
    </div>
  )
}

export default CreateStudent
      